To formalize the **`business/`** domain, we need to treat the **agentRoadmap** as more than a technical project—it is a **Digital Entity** with a strategy, a market position, and a cost-of-goods-sold (COGS) model.

The following template is designed for your agents to read and "self-align" their daily tasks with your long-term vision.

---

# `business/strategy.md`

## 🎯 1. North Star Vision (The Gary Vision)
* **Objective:** "To become the first fully autonomous, agent-native product development platform for specialized technical domains (AI, Material Science, IT Architecture)."
* **Target Value:** *Reduce the time-to-market for a digital artifact from months to hours.*
* **Competitive Edge:** Local-first security, **SpacetimeDB** real-time sync, and family-integrated SME (Subject Matter Expert) feedback loops.

---

## 🏗️ 2. Business Architecture Layers

### **A. Value Proposition (What we sell/build)**
* **Artifacts:** Codebases, Research Papers, Design Docs, and Infrastructure as Code (IaC).
* **Quality Standard:** Must pass the **`pipeline/`** 90% confidence threshold and **Skeptic (`RED-01`)** adversarial review.

### **B. Revenue & Cost Model (The Economy)**
* **COGS (Cost of Goods Sold):** Total Token Spend per RFC.
* **Efficiency Goal:** Maintain a >75% **Cache Hit Ratio** via optimized `context/` management.
* **Resource Allocation:** 60% Development, 20% Research, 20% Governance/Security.

---

## 📈 3. Key Performance Indicators (KPIs)
* **Workforce Velocity:** Average duration of the **RFC Lifecycle** (from *New* to *Complete*).
* **Agent Attrition:** Number of "Retired" agents in `workforce/` (indicates stability).
* **Decision Quality:** Ratio of *Accepted* vs. *Rejected* RFCs.
* **Family SME Alignment:** Percentage of RFCs that required manual correction from Derek (Material Science) or Nolan (UX).

---

## 🛤️ 4. Business Process Map (BPMN)



1.  **Visionary Trigger:** Human submits intent via **WebSash/TUI**.
2.  **Feasibility Gate:** **Auditor** calculates projected ROI vs. Budget.
3.  **Strategic Decomposition:** **Architect** maps RFCs to the Product DAG.
4.  **Adversarial Audit:** **Skeptic** verifies compliance with the `business/strategy.md`.
5.  **Artifact Fulfillment:** **Workforce** executes; **Pipeline** validates.

---

## 👨‍👩‍👦 5. Stakeholder Registry (The Human Proxy)
* **Gary (Chief Visionary):** Final sign-off on **Budget** and **Strategic Pivots**.
* **Derek (AI & Material Science SME):** Technical validation for specialized domain RFCs.
* **Nolan (UX & Quality Proxy):** Final review of TUI/WebSash interface evolution.

---

### **Implementation Logic for the Overhaul**

* **The "Strategy Check":** Before an **Architect** agent moves an RFC to the `Review` state, it must include a section called **"Strategic Alignment"** citing specific points from this `business/strategy.md` file.
* **The "Pulse" of the Business:** Your **WebSash** should display a "Strategy Heatmap"—showing which parts of your vision are currently being "worked on" by which squads.

### **Final Summary of the Overhaul Blueprints**
We have now mapped every critical domain for **agentRoadmap v2.0**:
1.  **Product:** 9-stage RFC lifecycle.
2.  **Project:** Task orchestration and Git-sync.
3.  **Workforce:** Profile-based specialized agents.
4.  **Spending:** Real-time mobile/TUI/WebSash monitoring.
5.  **Pipeline:** Pre-flight and QA verification.
6.  **Business:** Value-stream and strategy alignment.
7.  **Infrastructure:** SpacetimeDB & OpenClaw CLI control.

